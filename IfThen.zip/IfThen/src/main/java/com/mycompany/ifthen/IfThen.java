/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ifthen;

/**
 *
 * @author Arya
 */
public class IfThen {

    public static void main(String[] args) {
        boolean isOn = true;
        
        if (isOn) {
            System.out.println("Menyalakan Lampu");
        }
    }
    }

